hey kids! read instructions for lesson blah blah blah
